#![windows_subsystem = "windows"]

use eframe::egui;
use image::DynamicImage;
use std::path::PathBuf;

const SIZES: &[u32] = &[
    4, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40,
];

#[derive(PartialEq, Clone, Copy)]
enum Lang {
    En,
    Ru,
}

#[derive(PartialEq, Clone, Copy)]
enum ImageFormat {
    Png,
    Jpeg,
    Webp,
    Ico,
}

impl ImageFormat {
    fn extension(&self) -> &'static str {
        match self {
            Self::Png => "png",
            Self::Jpeg => "jpg",
            Self::Webp => "webp",
            Self::Ico => "ico",
        }
    }
}

enum Status {
    Initial,
    Loaded(u32, u32),
    Saved(String),
    Error(String),
}

impl Status {
    fn text(&self, lang: Lang) -> String {
        match (self, lang) {
            (Self::Initial, Lang::En) => "Load an image to start".to_string(),
            (Self::Initial, Lang::Ru) => "Загрузи изображение для начала".to_string(),
            (Self::Loaded(w, h), Lang::En) => format!("Loaded: {}x{} px", w, h),
            (Self::Loaded(w, h), Lang::Ru) => format!("Загружено: {}x{} px", w, h),
            (Self::Saved(name), Lang::En) => format!("💾 Saved to: {}", name),
            (Self::Saved(name), Lang::Ru) => format!("💾 Сохранено в: {}", name),
            (Self::Error(err), Lang::En) => format!("❌ Error: {}", err),
            (Self::Error(err), Lang::Ru) => format!("❌ Ошибка: {}", err),
        }
    }
}

struct CropperApp {
    image: Option<DynamicImage>,
    texture: Option<egui::TextureHandle>,
    selected_size: u32,
    crop_x: u32,
    crop_y: u32,
    zoom: f32,
    format: ImageFormat,
    output_name: String,
    lang: Lang,
    status: Status,
}

impl Default for CropperApp {
    fn default() -> Self {
        Self {
            image: None,
            texture: None,
            selected_size: 16,
            crop_x: 0,
            crop_y: 0,
            zoom: 2.0,
            format: ImageFormat::Png,
            output_name: "sprite".to_string(),
            lang: Lang::En,
            status: Status::Initial,
        }
    }
}

impl CropperApp {
    fn load_file(&mut self, ui: &egui::Ui, path: PathBuf) {
        match image::open(&path) {
            Ok(img) => {
                let rgba = img.to_rgba8();
                let (w, h) = rgba.dimensions();
                let color_image = egui::ColorImage::from_rgba_unmultiplied(
                    [w as usize, h as usize],
                    rgba.as_raw(),
                );

                self.texture = Some(ui.load_texture(
                    "sprite_sheet",
                    color_image,
                    egui::TextureOptions::NEAREST,
                ));
                self.crop_x = 0;
                self.crop_y = 0;
                self.status = Status::Loaded(w, h);
                self.image = Some(img);
            }
            Err(err) => {
                self.status = Status::Error(err.to_string());
            }
        }
    }

    fn save_crop(&mut self) {
        let img = match &self.image {
            Some(i) => i,
            None => return,
        };

        let default_file = format!("{}.{}", self.output_name, self.format.extension());
        let mut dialog = rfd::FileDialog::new().set_file_name(&default_file);

        dialog = match self.format {
            ImageFormat::Png => dialog.add_filter("PNG", &["png"]),
            ImageFormat::Jpeg => dialog.add_filter("JPEG", &["jpg", "jpeg"]),
            ImageFormat::Webp => dialog.add_filter("WebP", &["webp"]),
            ImageFormat::Ico => dialog.add_filter("ICO", &["ico"]),
        };

        if let Some(save_path) = dialog.save_file() {
            let cropped = img.crop_imm(
                self.crop_x,
                self.crop_y,
                self.selected_size,
                self.selected_size,
            );
            match cropped.save(&save_path) {
                Ok(_) => {
                    let fname = save_path
                        .file_name()
                        .map(|s| s.to_string_lossy().into_owned())
                        .unwrap_or_default();
                    self.status = Status::Saved(fname);
                }
                Err(e) => {
                    self.status = Status::Error(e.to_string());
                }
            }
        }
    }
}

impl eframe::App for CropperApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let lang = self.lang;

        // Панель управления
        egui::Panel::left("sidebar")
            .min_size(240.0)
            .show(ui, |ui| {
                // Шапка с переключателем языка
                ui.horizontal(|ui| {
                    ui.heading("✂️ Cicada");
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        ui.selectable_value(&mut self.lang, Lang::Ru, "RU");
                        ui.selectable_value(&mut self.lang, Lang::En, "EN");
                        ui.label("🌐");
                    });
                });

                ui.separator();

                let open_btn_text = match lang {
                    Lang::En => "📂 Open Image",
                    Lang::Ru => "📂 Открыть картинку",
                };
                if ui.button(open_btn_text).clicked() {
                    if let Some(path) = rfd::FileDialog::new()
                        .add_filter("Images", &["png", "jpg", "jpeg", "webp", "bmp", "ico"])
                        .pick_file()
                    {
                        self.load_file(ui, path);
                    }
                }

                ui.separator();
                let crop_size_label = match lang {
                    Lang::En => "Crop Size (px):",
                    Lang::Ru => "Размер кропа (px):",
                };
                ui.label(crop_size_label);
                egui::ComboBox::from_id_salt("crop_size")
                    .selected_text(format!("{}x{}", self.selected_size, self.selected_size))
                    .show_ui(ui, |ui| {
                        for &size in SIZES {
                            ui.selectable_value(
                                &mut self.selected_size,
                                size,
                                format!("{}x{}", size, size),
                            );
                        }
                    });

                ui.separator();
                let zoom_label = match lang {
                    Lang::En => "Zoom Scale:",
                    Lang::Ru => "Масштаб ленты:",
                };
                ui.label(zoom_label);
                ui.add(egui::Slider::new(&mut self.zoom, 1.0..=10.0).step_by(1.0).text("x"));

                ui.separator();
                let pos_label = match lang {
                    Lang::En => "Crop Position:",
                    Lang::Ru => "Координаты кропа:",
                };
                ui.label(pos_label);
                if let Some(img) = &self.image {
                    let max_x = img.width().saturating_sub(self.selected_size);
                    let max_y = img.height().saturating_sub(self.selected_size);

                    self.crop_x = self.crop_x.min(max_x);
                    self.crop_y = self.crop_y.min(max_y);

                    ui.horizontal(|ui| {
                        ui.label("X:");
                        ui.add(egui::DragValue::new(&mut self.crop_x).range(0..=max_x));
                    });
                    ui.horizontal(|ui| {
                        ui.label("Y:");
                        ui.add(egui::DragValue::new(&mut self.crop_y).range(0..=max_y));
                    });
                }

                ui.separator();
                let fname_label = match lang {
                    Lang::En => "File Name:",
                    Lang::Ru => "Имя файла:",
                };
                ui.label(fname_label);
                ui.text_edit_singleline(&mut self.output_name);

                let format_label = match lang {
                    Lang::En => "Format:",
                    Lang::Ru => "Формат:",
                };
                ui.label(format_label);
                ui.horizontal(|ui| {
                    ui.radio_value(&mut self.format, ImageFormat::Png, "PNG");
                    ui.radio_value(&mut self.format, ImageFormat::Webp, "WebP");
                    ui.radio_value(&mut self.format, ImageFormat::Ico, "ICO");
                    ui.radio_value(&mut self.format, ImageFormat::Jpeg, "JPG");
                });

                ui.add_space(8.0);
                let save_btn_text = match lang {
                    Lang::En => "💾 Save Crop",
                    Lang::Ru => "💾 Сохранить кроп",
                };
                let can_save = self.image.is_some();
                if ui.add_enabled(can_save, egui::Button::new(save_btn_text)).clicked() {
                    self.save_crop();
                }

                ui.separator();
                ui.label(self.status.text(lang));
            });

        // Холст отображения ленты
        if let (Some(tex), Some(img)) = (&self.texture, &self.image) {
            egui::ScrollArea::both()
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    let img_w = img.width() as f32 * self.zoom;
                    let img_h = img.height() as f32 * self.zoom;

                    let (rect, response) =
                        ui.allocate_exact_size(egui::vec2(img_w, img_h), egui::Sense::click_and_drag());

                    if response.clicked() || response.dragged() {
                        if let Some(pos) = response.interact_pointer_pos() {
                            let local_x = (pos.x - rect.min.x) / self.zoom;
                            let local_y = (pos.y - rect.min.y) / self.zoom;

                            let max_x = img.width().saturating_sub(self.selected_size);
                            let max_y = img.height().saturating_sub(self.selected_size);

                            let target_x = local_x.floor() as u32;
                            let target_y = local_y.floor() as u32;

                            self.crop_x = target_x.min(max_x);
                            self.crop_y = target_y.min(max_y);
                        }
                    }

                    let painter = ui.painter();
                    painter.image(
                        tex.id(),
                        rect,
                        egui::Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)),
                        egui::Color32::WHITE,
                    );

                    let sel_min = rect.min
                        + egui::vec2(
                            self.crop_x as f32 * self.zoom,
                            self.crop_y as f32 * self.zoom,
                        );
                    let sel_max = sel_min
                        + egui::vec2(
                            self.selected_size as f32 * self.zoom,
                            self.selected_size as f32 * self.zoom,
                        );
                    let sel_rect = egui::Rect::from_min_max(sel_min, sel_max);

                    painter.rect_stroke(
                        sel_rect,
                        0.0,
                        egui::Stroke::new(2.0, egui::Color32::from_rgb(255, 60, 60)),
                        egui::StrokeKind::Outside,
                    );
                    painter.rect_filled(
                        sel_rect,
                        0.0,
                        egui::Color32::from_rgba_unmultiplied(255, 60, 60, 45),
                    );
                });
        } else {
            ui.centered_and_justified(|ui| {
                let hint = match lang {
                    Lang::En => "Click \"📂 Open Image\" in the sidebar 👈",
                    Lang::Ru => "Нажми «📂 Открыть картинку» в боковой панели 👈",
                };
                ui.label(hint);
            });
        }
    }
}

// Загрузка вшитой иконки из корня проекта
fn load_embedded_icon() -> Option<egui::IconData> {
    let icon_bytes = include_bytes!("../cicada_logo.ico");
    if let Ok(img) = image::load_from_memory(icon_bytes) {
        let rgba = img.to_rgba8();
        let (width, height) = rgba.dimensions();
        return Some(egui::IconData {
            rgba: rgba.into_raw(),
            width,
            height,
        });
    }
    None
}

fn main() -> eframe::Result<()> {
    let mut viewport = egui::ViewportBuilder::default()
        .with_inner_size([1000.0, 700.0])
        .with_title("Cicada");

    if let Some(icon) = load_embedded_icon() {
        viewport = viewport.with_icon(icon);
    }

    let native_options = eframe::NativeOptions {
        viewport,
        ..Default::default()
    };

    eframe::run_native(
        "Cicada",
        native_options,
        Box::new(|_cc| Ok(Box::new(CropperApp::default()))),
    )
}